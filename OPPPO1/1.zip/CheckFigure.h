#pragma once
#include "string"
#include <sstream>
#include "List.h"
#include <regex>
#include <iostream>
#include "readOwner.h"
bool isInteger(std::string str);
bool isFloat(std::string str);
bool isOwner(std::string str);
bool isRibs(std::string str);
bool isBall(std::string figure);
bool isParallelepiped(std::string figure);
bool isCube(std::string figure);
void functionList(std::string function, List* list);
bool checkFigur(std::string  str, List* list);
bool checkFunction(std::string function);