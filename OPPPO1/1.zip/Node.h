#pragma once
#include "Figures.h"
class Node
{
public:
	Figures* figure[1];
	Node* link;
};

