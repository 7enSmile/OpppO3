#include "Parallelepiped.h"

void setRibs(std::string str, int* mass) {
	str.erase(0, 1);
	str.erase(str.size() - 1, str.size() - 1);
	str = std::regex_replace(str, std::regex(","), " ");
	std::stringstream stream(str);
	std::string teamp;
	stream >> mass[0];
	stream >> mass[1];
	stream >> mass[2];
}
Parallelepiped::~Parallelepiped()  {
	delete[] rib;


}
void Parallelepiped::setData(std::stringstream& stream) {
	float density;
	int weight;
	std::string ribs;
	stream >> ribs;
	setRibs(ribs, rib);
	stream >> density;
	Figures::setDensity(density);
	
	std::string name = readOwner(stream);
	if (name[0] == '\"') {
		name.erase(0, 1);
		name.erase(name.size() - 1, name.size() - 1);
	}

	Figures::setName(name);
	stream.get();
	if (!stream.eof()) {
		stream >> weight;
		Figures::setWeight(weight);

	}

}
void Parallelepiped::getData() {
	std::cout << "figure:parallelepiped " << "r1:" << rib[0] << " r2:" << rib[1] << " r3:" << rib[2];
	Figures::getDataFigure();
}
std::string Parallelepiped::getClass() {
	return "parallelepiped";
}
