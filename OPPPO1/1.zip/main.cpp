﻿#include <fstream>
#include <string>
#include <sstream>
#include "Figures.h"
#include "Ball.h"
#include "Cube.h"
#include "Parallelepiped.h"
#include "List.h"
#include "CheckFigure.h"
void addList(std::string str,List *list) {
	Figures* object;
	std::string type;
	std::string figure;
	std::stringstream stream(str);
	stream >> type;
	if (type == "ball") {
		object = new Ball;
		object->setData(stream);
		list->push(object);
	}
		

	if (type == "parallelepiped") {

		object = new Parallelepiped;
		object->setData(stream);
		list->push(object);
	}
		

	if (type == "cube"){

		object = new Cube;
		object->setData(stream);
		
		list->push(object);
		

	}
}

 int main() {
	 setlocale(LC_ALL, "Russian");
	 setlocale(LC_NUMERIC, "C");
	 std::fstream in("in.txt");
	 std::string str;
	 
	 List* list = new List();
	
	
	while (!in.eof()) {
		std::getline(in, str);
		if (checkFigur(str,list)) {
			addList(str,list);
		}
		else {

		}

	}
	
	
	list->print();
	
	delete list;
	
	
	return 1;

	
}

