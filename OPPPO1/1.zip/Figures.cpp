#include "Figures.h"
#include "iostream"
Figures::~Figures(){

}
void Figures::setWeight(int teampWeight) {
	weight = teampWeight;

}
void Figures::setName(std::string teampName) {
	name = teampName;
}
void Figures::setDensity(float teampDensity) {
	density = teampDensity;
}
void Figures::getDataFigure() {
	if (weight != 0) {
		std::cout << " density:" << density << " owner:" << name << " weight:" << weight << std::endl;
	}
	else {
		std::cout << " density:" << density << " owner:" << name << std::endl;
	}

}
std::string Figures::getName() {
	return name;
}