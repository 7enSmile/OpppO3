#include "CheckFigure.h"
bool isInteger(std::string str) {
	for (int i = 0; i < str.size(); i++)
		if (!isdigit(str[i]))
			return 0;
	return 1;
}
bool isFloat(std::string str) {
	int countPoint = 0;
	if (str[0] == '.' || str[str.size() - 1] == '.')
		return 0;
	for (int i = 0; i < str.size(); i++) {
		if (!isdigit(str[i])) {
			if (str[i] != '.')
				return 0;
			countPoint++;
		}
	}
	if (countPoint >= 2 || countPoint == 0)
		return 0;
	else
		return 1;


}

bool isOwner(std::string str) {
	int i = 0;
	bool split = 0;
	bool checkSpace = 0;

	if (str[i] == '\"') {
		split = 1;
		i++;
	}
	else {
		if ((str[i] >= 'A' && str[i] <= 'Z') || (str[i] >= '�' && str[i] <= '�')) {
			i++;
		}
		else
			return 0;

	}
	if (split) {
		if ((str[i] >= 'A' && str[i] <= 'Z') || (str[i] >= '�' && str[i] <= '�')) {
			i++;
		}
		else {
			return 0;
		}
	}

	for (; i < str.size(); i++) {
		if (split && str[i] == ' ') {
			checkSpace = 1;
		}
		else {
			if (!split && str[i] == ' ')
				return 0;
		}

	}
	if (split) {
		if (checkSpace && str[str.size() - 1]=='\"')
			return 1;
		else
			return 0;
	}
	else
		return 1;
}

bool isRibs(std::string str) {

	str.erase(0, 1);
	str.erase(str.size() - 1, str.size() - 1);
	str = std::regex_replace(str, std::regex(","), " ");
	std::stringstream stream(str);
	std::string teamp;
	stream >> teamp;
	if (!isInteger(teamp))
		return false;
	stream >> teamp;
	if (!isInteger(teamp))
		return false;
	stream >> teamp;
	if (!isInteger(teamp))
		return false;
	if (!stream.eof()) {
		return false;

	}
	return true;



}

bool isBall(std::string figure) {
	std::stringstream stream(figure);
	std::string teamp;
	stream >> teamp;
	if (!isInteger(teamp))
	{
		return 0;
	}

	stream >> teamp;

	if (!isFloat(teamp)) {
		return 0;
	}

	std::string owner = readOwner(stream);
	if (!isOwner(owner)) {
		return 0;
	}
	stream.get();
	if (!stream.eof()) {
		stream >> teamp;
		if (!isInteger(teamp))
			return 0;
	}
	if (stream.eof()) {
		return 1;
	}
	else
		return 0;

}
bool isParallelepiped(std::string figure) {
	std::stringstream stream(figure);
	std::string teamp;
	stream >> teamp;
	if (!isRibs(teamp))
	{
		return 0;
	}

	stream >> teamp;

	if (!isFloat(teamp)) {
		return 0;
	}
	std::string owner = readOwner(stream);
	if (!isOwner(owner)) {
		return 0;
	}
	stream.get();
	if (!stream.eof()) {
		stream >> teamp;
		if (!isInteger(teamp))
			return 0;
	}
	
	
	


	if (stream.eof()) {
		return 1;
	}
	else
		return 0;

}
bool isCube(std::string figure) {
	std::stringstream stream(figure);
	std::string teamp;
	stream >> teamp;
	if (!isInteger(teamp))
	{
		return 0;
	}

	stream >> teamp;

	if (!isFloat(teamp)) {
		return 0;
	}

	std::string owner = readOwner(stream);
	if (!isOwner(owner)) {
		return 0;
	}
	stream.get();
	if (!stream.eof()) {
		stream >> teamp;
		if (!isInteger(teamp))
			return 0;
	}

	if (stream.eof()) {
		return 1;
	}
	else
		return 0;

}

void functionList(std::string function, List* list) {
	std::string teamp;
	std::stringstream stream(function);
	bool isDelete = 0;
	bool isSort = 0;
	if (checkFunction(function)) {
		stream >> teamp;
		stream >> teamp;
		if (teamp == "delete") {
			stream >> teamp;
			list->deleteFigure(teamp);

		}
		else {
			list->sort();

		}

	}

}
bool checkFigur(std::string  str, List* list) {

	std::string function = str;
	std::string type;
	std::string figure;
	std::stringstream stream(str);
	stream >> type;
	while (stream >> str) {
		figure += " " + str;
	}
	figure.erase(0, 1);
	if (type == "ball") {
		return isBall(figure);
	}
	if (type == "parallelepiped") {
		return  isParallelepiped(figure);
	}
	if (type == "cube") {
		return isCube(figure);
	}
	functionList(function, list);
	return 0;

}
bool checkFunction(std::string function) {
	std::string teamp;
	std::stringstream stream(function);
	stream >> teamp;
	if (teamp == "function") {
		stream >> teamp;
		if (teamp == "delete") {
			stream >> teamp;
			if (teamp == "ball" || teamp == "cube" || teamp == "para" || teamp == "parallelepiped") {
				if (stream.eof()) {
					return 1;
				}
				else
					return 0;

			}
			else
				return 0;

		}
		else {
			if (teamp == "sort") {
				stream >> teamp;
				if (teamp == "name") {
					if (stream.eof()) {
						return 1;
					}
					else
						return 0;

				}
				else
					return 0;

			}
			else {

				return 0;
			}

		}


	}
	else
	{
		return 0;

	}

}