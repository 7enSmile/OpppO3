#pragma once
#include "string"
#include "sstream"
std::string readOwner(std::stringstream& stream);